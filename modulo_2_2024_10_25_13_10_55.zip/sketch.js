let cor; //criando a variável cor
let posicaoHorizontal; //(x) //criando a variável "posicaoHorizontal"
let posicaoVertical; //(y) //criando a variável "posicaoVertical"

function setup() {
  
  createCanvas(400, 400); //criando o cenário
  background ("white"); //cor do cenário
  cor = color(random(0, 255), random(0, 255), random(0, 55)); //variável "cor", cores aleatórias
  posicaoHorizontal = 200; //valor da variáve
  posicaoVertical = 200; //valor da variável
}

function draw() { //função de desenhar
  
  fill (cor)//cor do círculo
   circle(posicaoHorizontal, posicaoVertical, 50)//tamanho e posição do círculo
  
  if(mouseX < posicaoHorizontal) {
    posicaoHorizontal = posicaoHorizontal - 1 //se o mouseX for menor que a "posicaoHorizontal", vai diminuir o valor de 1 em 1 da "posicaoHorizontal"
  }
  
  if(mouseX > posicaoHorizontal) {
    posicaoHorizontal = posicaoHorizontal + 1 //se o mouseX for maior que a "posicaoHorizontal", vai aumentar o valor de 1 em 1 da "posicaoHorizontal"
  }
  
  if(mouseY < posicaoVertical) {
    posicaoVertical-- //se o mouseY for menor que a "posicaoVertical", vai diminuir o valor de 1 em 1 da "posicaoVertical"
  }
  
    if(mouseY > posicaoVertical) {
    posicaoVertical++ //se o mouseY for maior que a "posicaoVertical", vai aumentar o valor de 1 em 1 da "posicaoVertical"
  }
  
  if(mouseIsPressed){
  cor = color(random(0, 255), random(0, 255), random(0, 55),
random(0, 100)); //variável "cor", cores aleatórias
  } //se o mouse for pressionado a cor do círculo muda
  

}